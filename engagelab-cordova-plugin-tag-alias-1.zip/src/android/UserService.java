package com.engagelab.push;

import com.engagelab.privates.common.component.MTCommonService;

public class UserService extends MTCommonService {
}
